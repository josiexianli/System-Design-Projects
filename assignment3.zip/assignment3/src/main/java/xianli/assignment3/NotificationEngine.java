package xianli.assignment3;

public class NotificationEngine {
	public NotificationEngine() {
		
	}
	
	public void sendEmail(int actorId) {
		System.out.println("An email has been sent to Patron with id " + actorId + " for notification");
	}
}
